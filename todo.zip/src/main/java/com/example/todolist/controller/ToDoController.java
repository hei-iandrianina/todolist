package com.example.todolist.controller;

import com.example.todolist.model.ToDo;
import com.example.todolist.repository.ToDoRepository;
import com.example.todolist.service.ToDoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class ToDoController {
    @Autowired
    ToDoService service;
    @GetMapping("/")
    public static String hello(){
        return "Hello Joe";
    }
    @GetMapping("/todo/{id}")
    public ToDo getToDobyId(@PathVariable("id") Long pk){
        return service.getToDoById(pk);
    }

    @GetMapping("/todo")
    public List<ToDo> getAllToDo(){
        return service.getAllToDo();
    }
    @GetMapping("/todo/{id}/{ref}/{description}/{statut}")
    public ToDo createToDo(@PathVariable("id") Long pk, @PathVariable("ref") String ref,
                           @PathVariable String description, @PathVariable String statut){
        return service.createToDo(pk, ref, description, statut);
    };

    @GetMapping("/todo/delete/{id}")
    public void deleteToDo(@PathVariable("id") Long pk){
        service.deleteToDo(pk);
    }
    @GetMapping("/todo/update/{id}")
    public ToDo updateTodo(@PathVariable("id") Long pk){
        return service.updateToDo(pk);
    }
}
